function attachButtonToSVG(svg, isD3Chart) {
    const btn = document.createElement("button");
    btn.textContent = isD3Chart ? "Send D3 Chart" : "Send SVG";
    btn.style.position = "absolute";
    btn.style.zIndex = "1000";

    const rect = svg.getBoundingClientRect();
    btn.style.left = rect.left + "px";
    btn.style.top = rect.top + "px";

    btn.onclick = function() {
        if (isD3Chart) {
            const d3Data = extractD3Data(svg);
            sendChartToServer(d3Data, "d3");
        } else {
            sendChartToServer(svg.outerHTML, "svg");
        }
    };

    document.body.appendChild(btn);
}

function extractD3Data(svg) {
    // This function extracts the relevant data for the D3.js chart
    // Depending on the chart, you might need to extract data bindings, attributes, etc.
    const data = {
        outerHTML: svg.outerHTML,  // You can still extract the outer SVG HTML
        // Add more fields here to capture the actual D3 data (e.g., bound data)
    };
    return data;
}

function sendChartToServer(chartData, chartType) {
    const endpoint = chartType === "d3" ? 'http://localhost:5006/d3' : 'http://localhost:5006/svg';

    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ chart: chartData, type: chartType })
    })
    .then(response => {
        if (response.headers.get("content-type") && response.headers.get("content-type").includes("application/json")) {
            return response.json();
        } else {
            return response.text();
        }
    })
    .then(data => {
        window.open('http://localhost:5006', '_blank');
    })
    .catch(error => console.error('Error:', error));
}

function isD3Chart(svg) {
    // Simple check if the SVG has any elements or attributes commonly used by D3.js
    // You can extend this to check for more complex D3 properties.
    return svg.querySelector("[data-d3], .d3, [class*='d3']") !== null;
}

function detectCharts() {
    const svgs = Array.from(document.getElementsByTagName('svg'));
    console.log(`Detected ${svgs.length} SVGs on the page.`);

    svgs.forEach(svg => {
        const isD3 = isD3Chart(svg);  // Check if it's a D3-generated chart
        attachButtonToSVG(svg, isD3);
    });
}

// Initialize the detection and button attachment process
detectCharts();
